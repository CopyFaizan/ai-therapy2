import React, { useState, useCallback, useEffect } from 'react';
import WelcomeScreen from './components/WelcomeScreen';
import FeelingInput from './components/FeelingInput';
import ImageGeneration from './components/ImageGeneration';
import Reflection from './components/Reflection';
import SessionHistory from './components/SessionHistory';
import ApiKeyPrompt from './components/ApiKeyPrompt';
import { useLocalStorage } from './hooks/useLocalStorage';
import type { Session, AppState } from './types';
import { HistoryIcon } from './constants';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>('welcome');
  const [sessions, setSessions] = useLocalStorage<Session[]>('art-therapy-sessions', []);
  const [currentPrompt, setCurrentPrompt] = useState<string>('');
  const [currentImageUrl, setCurrentImageUrl] = useState<string>('');
  const [isApiKeyReady, setIsApiKeyReady] = useState(false);

  useEffect(() => {
    const checkApiKey = async () => {
      if (window.aistudio) {
        const hasKey = await window.aistudio.hasSelectedApiKey();
        setIsApiKeyReady(hasKey);
      }
    };
    checkApiKey();
  }, []);

  const handleSelectKey = useCallback(async () => {
    if (window.aistudio) {
      await window.aistudio.openSelectKey();
      // Assume success and optimistically update UI to avoid race conditions.
      setIsApiKeyReady(true);
    }
  }, []);

  const handleApiKeyError = useCallback(() => {
    setIsApiKeyReady(false);
  }, []);

  const handleStart = useCallback(() => {
    setCurrentPrompt('');
    setCurrentImageUrl('');
    setAppState('feeling_input');
  }, []);

  const handleFeelingsSubmit = useCallback((prompt: string) => {
    setCurrentPrompt(prompt);
    setAppState('generating');
  }, []);

  const handleImageGenerated = useCallback((imageUrl: string) => {
    setCurrentImageUrl(imageUrl);
    setAppState('reflection');
  }, []);

  const handleReflectionSave = useCallback((reflection: string) => {
    const newSession: Session = {
      id: new Date().toISOString(),
      prompt: currentPrompt,
      imageUrl: currentImageUrl,
      reflection: reflection,
      timestamp: new Date().getTime(),
    };
    setSessions([newSession, ...sessions]);
    setAppState('history');
  }, [currentImageUrl, currentPrompt, sessions, setSessions]);

  const handleShowHistory = useCallback(() => {
    setAppState('history');
  }, []);
  
  const renderContent = () => {
    switch (appState) {
      case 'welcome':
        return <WelcomeScreen onStart={handleStart} />;
      case 'feeling_input':
        return <FeelingInput onSubmit={handleFeelingsSubmit} />;
      case 'generating':
        return <ImageGeneration prompt={currentPrompt} onGenerated={handleImageGenerated} onBack={() => setAppState('feeling_input')} onApiKeyError={handleApiKeyError} />;
      case 'reflection':
        return <Reflection imageUrl={currentImageUrl} onSave={handleReflectionSave} />;
      case 'history':
        return <SessionHistory sessions={sessions} onNewSession={handleStart} />;
      default:
        return <WelcomeScreen onStart={handleStart} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-100 via-purple-100 to-pink-100 text-gray-800 flex flex-col items-center justify-center p-4 selection:bg-purple-300 selection:text-purple-900">
        {!isApiKeyReady ? (
            <ApiKeyPrompt onSelectKey={handleSelectKey} />
        ) : (
            <>
                {appState !== 'welcome' && appState !== 'history' && (
                     <button
                        onClick={handleShowHistory}
                        className="absolute top-4 right-4 text-gray-600 hover:text-indigo-600 transition-colors p-2 rounded-full bg-white/50 backdrop-blur-sm shadow-md"
                        aria-label="View Session History"
                      >
                        <HistoryIcon className="w-6 h-6" />
                    </button>
                )}
                {renderContent()}
            </>
        )}
    </div>
  );
};

export default App;